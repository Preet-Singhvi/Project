const express = require("express");
const app = express();
const mongoose = require("mongoose");
const AddressSchema = require('../schema/address_schema');
// const AddressModel = require('../helper');

let masterConnectionVar  = {};
let masterConnection = "";

let db_name = "";
function getDbName(){
    return db_name;
}

app.post('/enable_db',async (req,res) =>{
    db_name = req.body.db_name;
    // let addressmodel =await AddressModel.connectToDb(db_name);
    // console.log('on helper:',addressmodel);
    setTimeout(()=>{
        // let addressModel = AddressModel.getAddressModel();
        // console.log('addressModel:',addressModel)
        let url = 'mongodb://127.0.0.1:27017/'+db_name;
        console.log('url:',url);
        masterConnection = mongoose.createConnection(url);
        masterConnection.on('connected',function(e){
            let masterAddressModel = masterConnection.model("addresses",AddressSchema);
            masterConnectionVar = {
                "addresses" : masterAddressModel
            }
        })
        res.json('db ' + db_name + ' connected successfully');
    },300)
});

function getLatestUtilities(){
    return masterConnectionVar.addresses;
}



module.exports = {
    "app" : app,
    "getDbName" : getDbName,
    getMasterAddresses : getLatestUtilities
};