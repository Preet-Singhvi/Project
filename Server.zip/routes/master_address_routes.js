const express = require("express");
const app = express();
const Addresses_master = require('../routes/enable_db_routes');
const helper = require('../helper');

app.get("/get_addresses", async (request, res) => {
    helper.connectToDb(request.query.db_name);
    setTimeout(async()=>{
        let addresses = helper.getAddressModel();
        console.log('addresses on get:',addresses);
        let query = {};
        // let addresses = Addresses_master.getMasterAddresses();
        if(request.body.queries && request.body.queries.length > 0) {
            request.body.queries.map((q) =>{
                query[Object.keys(q)[0]] = Object.values(q)[0];
            })
        }
        console.log('query:',query);
        // await addresses.createCollection();
        await addresses.find(query)
        .then(response =>{
            res.json(response);
        })
        .catch (error => {
            res.status(500).send(error);
        })
    },200)
});

app.post("/add_address", async (req, res) => {
    console.log(req.body.address);
    helper.connectToDb(req.body.db_name);
    setTimeout(async()=>{
        let addresses = helper.getAddressModel();
        const newAddress = new addresses(req.body);
        await newAddress.save()
        .then(response =>{
            console.log('addressResult',response);
            res.json(response);
        })
        .catch(error =>{
            res.send(error)
        })
    },200)
});

app.post("/add_addresses", async (req, res) => {
    helper.connectToDb(req.body.db_name);
    setTimeout(async()=>{
        let addresses = helper.getAddressModel();
        console.log(req.body.addresses);
        addresses.insertMany(req.body.addresses)
        .then(response =>{
            console.log('documents updated:',response.length);
            res.json(response);
        })
        .catch(function(error){
            res.send(error);   
        });
    },200)
});

app.post("/update_address",async(req,res) =>{
    helper.connectToDb(req.body.db_name);
    setTimeout(async()=>{
        let addresses = helper.getAddressModel();
        let find = {[req.body.key] : req.body.value}
        let update = {[req.body.updateKey] : req.body.updateValue}
        if(req.body.updatedObject && req.body.updatedObject !== "") {
            update = req.body.updatedObject;
        }
        console.log('fid and update:',find,update);
        await addresses.findOneAndUpdate(find,update)
        .then(response =>{
            console.log('documents updated:',response.length);
            res.json(response);
        })
        .catch(function(error){
            res.send(error);   
        });
    },200)
})

app.delete("/delete_address", async (req, res) => {
    helper.connectToDb(req.body.db_name);
    setTimeout(async()=>{
        let addresses = helper.getAddressModel();
        console.log(req.body.key);
        await addresses.deleteOne({[req.body.key] : req.body.value})
        .then(response =>{
            console.log('documents deleted:',response)
            res.json(response);
        })
        .catch(function(error){
            res.send(error);  
        });
    },200);
});

module.exports = app;