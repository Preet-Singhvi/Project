const mongoose = require("mongoose");
const AddressSchema = require('./schema/address_schema');

var masterConnectionVar = {
    "addresses" : {}
};

async function connectToDb(dbname) {
    let url = 'mongodb://127.0.0.1:27017/'+dbname;
    console.log('url:',url);
    masterConnection = mongoose.createConnection(url);
    await masterConnection.on('connected',function(e){
        let masterAddressModel = masterConnection.model("addresses",AddressSchema);
        masterConnectionVar = {
            "addresses" : masterAddressModel
        }
    })
}

function getAddressModel() {
    return masterConnectionVar.addresses;
}

module.exports ={
    connectToDb : connectToDb,
    getAddressModel : getAddressModel
};