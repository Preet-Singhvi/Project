const express = require("express");
// const mongoose = require("mongoose");
const enable_db_router = require('./routes/enable_db_routes');
// const utilities_addresses_router = require('./routes/utilities_address_routes');
const master_addresses_router = require('./routes/master_address_routes');

let enable_db_app = enable_db_router.app;

const childProcess = require('child_process');

const app = express();

app.use(express.json());

app.use(enable_db_app);
// app.use(utilities_addresses_router);
app.use(master_addresses_router);

app.listen(8080, () => {
  console.log("Server is running at port 8080");
});
