const mongoose = require('mongoose');

const AddressSchema = mongoose.Schema({
    bdc_url: {
        type: String,
        required: true,
    },
    address: {
        type: String,
        required: true
    },
    latlng: {
        type: String,
        required: true
    },
    state_code: {
        type: String,
        required: true
    },
    county_code: {
        type: String,
        required: true
    },
    index : {
        type : Number,
        required: true
    }
},{
    strict : false
});

module.exports = AddressSchema;