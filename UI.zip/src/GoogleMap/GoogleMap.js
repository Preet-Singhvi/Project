import React, { useEffect, useState } from 'react';
import axios from "axios";
import { Box, Typography } from '@mui/material';

const GOOGLE_API_KEY = "AIzaSyCAkrrI9w-4LVsBcDVea4LjyTz0NNEucmc";
export const GetSearchAddressGeocode = async (searchInput) => {
    try {
        const response = await axios.get('https://maps.googleapis.com/maps/api/geocode/json', {
            params: {
                address: searchInput,
                key: GOOGLE_API_KEY
            }
        });
        return response;
    } catch (error) {
        console.error(error);
    }
}

const GoogleMap = (props) => {
    const [StreetViewPanoId, setStreetViewPanoId] = useState();

    const GetStreetView = () => {
        try {
            GetSearchAddressGeocode(props.address).then((response) => {
                const location = response?.data.results[0].geometry.location;
                console.log(location);
                // let oStreetViewOptions = {
                //     position: location,
                //     addressControl: false,
                //     showRoadLabels: true,
                //     zoomControl: true,
                //     enableCloseButton: false,
                //     visible: true
                // }
                const map = new window.google.maps.Map(document.getElementById("google_map"), {
                    zoom: 18,
                    center: location,
                    mapTypeId: window.google.maps.MapTypeId.SATELLITE
                });
                // The marker, positioned at Uluru
                const marker = new window.google.maps.Marker({
                    position: location,
                    map: map,
                });
                // var streetViewService = new window.google.maps.StreetViewService();
                // var STREETVIEW_MAX_DISTANCE = 100;
                // var latLng = new window.google.maps.LatLng(location.lat, location.lng);
                // streetViewService.getPanoramaByLocation(latLng, STREETVIEW_MAX_DISTANCE, function (streetViewPanoramaData, status) {
                //     if (status === window.google.maps.StreetViewStatus.OK) {
                //         let oPanorama = new window.google.maps.StreetViewPanorama(
                //             document.getElementById("streetview_map"),
                //             oStreetViewOptions
                //         );
                //         setStreetViewPanoId(true);
                //     } else {
                //         setStreetViewPanoId(false);
                //     }
                // });
            })
                .catch((error) => {
                    console.log(error);
                })
        } catch (error) {
            console.error(error);
        }
    }

    useEffect(() => {
        GetStreetView();
    }, [props.address])

    // useEffect(() => {
    // }, [StreetViewPanoId])


    return (
        <>
            <Box id='google_map' sx={{ height: "100%", width: "100%" }}></Box>
            {/* {!StreetViewPanoId &&
                <Box id='no_streetview_map' sx={{ height: "100%", width: "100%", display: 'flex', backgroundColor: 'lightgrey', justifyContent: 'center', alignItems: 'center' }}>
                    <Typography>Streetview not available</Typography>
                </Box>} */}
        </>
    )
}

export default GoogleMap