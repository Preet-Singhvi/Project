import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Home/Home';

// var element = React.createElement('h1', { className: 'greeting' }, 'Hello, world!');
// ReactDOM.render(element, document.getElementById('root'));

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // <React.StrictMode>
  //   <App />
  // </React.StrictMode>
  <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} ></Route>
        <Route path="/home" element={<Home />} ></Route>
      </Routes>
    </BrowserRouter>
);
reportWebVitals();
