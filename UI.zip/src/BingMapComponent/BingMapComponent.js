import * as React from 'react';
import { ReactBingmaps, GeolocateControl } from 'react-bingmaps';

const BingMapComponent = ({ address }) => {

  const [center, setCenter] = React.useState(null);
  const mapRef = React.useRef(null);

  // Function to get the latitude and longitude from an address using a geocoding API
  async function getLatLngFromAddress(address) {
    const apiKey = 'AIzaSyDudtaSB3fXindR6nRwx9lgCFDej4Vj3mc'; // Replace with your API key
    const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`);
    const data = await response.json();
    if (data.results.length > 0) {
      const location = data.results[0].geometry.location;
      return [location.lat, location.lng];
    } else {
      return [];
    }
  }


  // Function to set the map center to a new latitude and longitude
  function setMapCenter(lat, long) {
    setCenter([lat, long]);
    if (mapRef.current) {
      mapRef.current.setView({ center: [lat, long], zoom: 18 });
    }
  }

  // UseEffect to get latitude and longitude from address and set map center on mount
  React.useEffect(() => {
    async function fetchData() {
      if (!address) {
        return;
      }
      const [lat, long] = await getLatLngFromAddress(address);
      if (lat && long) {
        setMapCenter(lat, long);
      }
    }
    fetchData();
  }, [address]);

  // Do not render map until center is set
  if (!center) {
    return null;
  }

  return (
    <ReactBingmaps
      ref={mapRef}
      bingmapKey="AovSF3--QkbGI_ONA23dtFdICfyJ1wGRr8JdCE8nR60dHGeeWGbeHsrJgCri47E2"
      center={center}
      mapTypeId={"aerial"}
      pushPins={[
        {
          location: center, "option": { color: 'red' }
        },
      ]}
      zoom={18}
    />
  );
};

export default BingMapComponent;





// import * as React from 'react';
// import { ReactBingmaps } from 'react-bingmaps';

// const BingMapComponent = ({ url }) => {
//   const [center, setCenter] = React.useState(null);
//   const mapRef = React.useRef(null);

//   // Function to extract the latitude and longitude from a URL parameter
//   function getLatLngFromUrl(url) {
//     const searchParams = new URLSearchParams(url);
//     const cp = searchParams.get('cp');
//     if (cp) {
//       const [lat, long] = cp.split('~');
//       return [Number(lat), Number(long)];
//     } else {
//       return null;
//     }
//   }

//   // Function to set the map center to a new latitude and longitude
//   function setMapCenter(lat, long) {
//     setCenter([lat, long]);
//     if (mapRef.current) {
//       mapRef.current.setView({ center: [lat, long], zoom: 18 });
//     }
//   }

//   // UseEffect to extract latitude and longitude from URL parameter and set map center on mount
//   React.useEffect(() => {
//     const [lat, long] = getLatLngFromUrl(url);
//     setMapCenter(lat, long);
//   }, [url]);

//   // Do not render map until center is set
//   if (!center) {
//     return null;
//   }

//   return (
//     <ReactBingmaps
//       ref={mapRef}
//       bingmapKey="AovSF3--QkbGI_ONA23dtFdICfyJ1wGRr8JdCE8nR60dHGeeWGbeHsrJgCri47E2" 
//       center={center}
//       mapTypeId={"aerial"} 
//       pushPins={[
//         {
//           location: center, "option":{ color: 'red' }
//         },
//       ]}
//       zoom={18}
//     />
//   );
// };

// export default BingMapComponent;