import * as React from 'react';
import './App.css';
import { useState, useEffect } from "react";
import { Box, Button, Divider, Grid, Stack, Switch, Typography } from "@mui/material";
// import addresses from '../src/addresses.json';
// import addresses from '../src/addresses_new.json';
// import addresses from '../src/Prirority_URL.json';
// import { createRoot } from 'react-dom/client';

import BingMapComponent from './BingMapComponent/BingMapComponent.js'
import IframeComponent from './iframeComponent/iframeComponent';
import StreetView from './StreetView/StreetView';
import GoogleMap from './GoogleMap/GoogleMap';

import axios from 'axios';

const App = () => {

  const [saddresses, setAddresses] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    // axios({
    //   url : '/enable_db',
    //   method : 'POST',
    //   data : {
    //     "db_name" : "comcast"
    //   }
    // })
    // .then(response =>{
    //   console.log('db connected');
      axios({
        url: "/get_addresses?db_name=comcast",
        method: "GET"
      })
      .then((res) => {
        console.log('response on get addresses:',res);
        let addresses = res.data;
        addresses.sort((a,b) =>a.priority - b.priority);
        console.log('sorted array:',addresses);
        setAddresses(addresses);
      })
      .catch((err) => {
        console.log('error on get addresses:,',err);
      });
    // })
    // .catch(error =>{
    //   console.log('error on db:',error);
    // })
  }, []);

  const previousAddress = () => {
    setCurrentIndex(currentIndex > 0 ? currentIndex - 1 : saddresses.length - 1);
  };

  const nextAddress = () => {
    setCurrentIndex(currentIndex < saddresses.length - 1 ? currentIndex + 1 : 0);
  };

  const [currentAddressIndex, setCurrentAddressIndex] = useState(0);
  const [secondIframeSrc, setSecondIframeSrc] = useState(saddresses[currentIndex]?.google_url);
  const [isIframeShown, setIsIframeShown] = useState(true);
  const [showStreetView, setShowStreetView] = useState(false);

  const ToggleStreetView = () => {
    try {
      setShowStreetView(!showStreetView);
    } catch (error) {
      console.error(error);
    }
  }

  const toggleMap = () => {
    if (isIframeShown) {
      setIsIframeShown(false);
    } else {
      setIsIframeShown(true);
    }
  };

  useEffect(() => {
    setSecondIframeSrc(saddresses[currentIndex]?.google_url);
  }, [saddresses, currentIndex]);

  return (
    <Box sx={{ height: '99%', width: '99%', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ height: "70%", margin: "5px", width: '100%', display: 'flex', flexDirection: 'row' }}>
        <Box sx={{ height: "100%", width: '50%' }}>
          <IframeComponent src={saddresses[currentIndex]?.bdc_url} />
        </Box>
        <Box sx={{ height: "100%", width: '50%' }}>
          {!showStreetView ?
            (isIframeShown ? (
              <GoogleMap address={saddresses[currentIndex]?.address} />) :
              (<BingMapComponent address={saddresses[currentIndex]?.address} />))
            : <StreetView address={saddresses[currentIndex]?.address} />
          }
        </Box>
      </Box>
      <Divider sx={{ marginTop: "5px" }}></Divider>
      <Box sx={{ height: "25%", width: '100%', display: 'flex', flexDirection: 'row' }}>
        <Box sx={{ height: '100%', width: '49%', padding: "10px", display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
          <Typography sx={{ mt: "10px", mb: "10px" }}>Address: {saddresses[currentIndex]?.address}</Typography>
          <textarea placeholder="Enter your comment here" style={{ width: "90%", height: "50%" }} />
        </Box>

        <Box sx={{
          height: '100%', width: '49%', display: "flex", flexDirection: "column", justifyContent: "flex-end"
        }}>
          <Box sx={{ marginTop: '10px', height: '75%', display: 'flex', flexDirection: 'row' }}>
            <Box sx={{ width: '50%', display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
              {/* <Box> */}
              <Typography sx={{ fontSize: "20px", fontWeight: "600" }} color="rgb(0,0,0,0.5)">House Pass Recovery:</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start', margin: 'auto', height: '90%', width: '100%' }}>
                <Button variant="contained" color="success"
                  sx={{ margin: '10px', width: '45%' }}
                // style={{ fontSize: 30, marginLeft: 250, marginRight: 10 }}
                >
                  Yes
                </Button>
                <Button variant="contained" color="error"
                  sx={{ margin: '10px', width: '45%' }}
                // style={{ fontSize: 30, marginRight: 50 }}
                >
                  No
                </Button>
              </Box>
              {/* </Box> */}

            </Box>
            <Divider orientation='vertical'></Divider>
            <Box sx={{ width: '50%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', margin: "10px" }}>
              <Stack
                direction="row"
                spacing={1}
                sx={{ alignItems: 'center', height: '20%', width: '100%', justifyContent: 'flex-start' }}
              >
                <Box sx={{ width: "99%", display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "flex-start" }}>
                  <Typography className='App-typography' sx={{ width: "50%", fontWeight: "500" }}>Map : </Typography>
                  <Typography className='App-typography' sx={{ color: "rgb(0,0,0,0.7)" }}>Bing</Typography>
                  <Switch
                    checked={isIframeShown}
                    onChange={toggleMap}
                  />
                  <Typography className='App-typography' sx={{ color: "rgb(0,0,0,0.7)" }}>Google</Typography>
                </Box>
              </Stack>

              {/* <Box sx={{display: 'flex', flexDirection: 'row', alignItems:'center',justifyContent:'center'}}> */}
              {/* <Typography sx={{marginRight:'15px'}}>StreetView</Typography> */}
              <Stack
                direction="row"
                spacing={1}
                sx={{ alignItems: 'center', height: '40%', width: '100%', justifyContent: 'flex-start' }}
              >
                <Box sx={{ width: "99%", display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "flex-start" }}>
                  <Typography className='App-typography' sx={{ width: "50%", fontWeight: "500" }}>Google Streetview : </Typography>
                  <Typography className='App-typography' color={'error'}>Off</Typography>

                  <Switch
                    checked={showStreetView}
                    onChange={ToggleStreetView}
                  />
                  <Typography color={'success'} >On</Typography>
                </Box>
              </Stack>
              {/* </Box> */}

            </Box>
          </Box>
          <Divider></Divider>
          <Box sx={{ marginTop: '10px', height: '20%', width: '100%', display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Button
              onClick={previousAddress}
              sx={{ cursor: 'pointer', width: '50%', mr: "5px" }}
              variant="outlined"
              color="primary"
            >
              Previous Address
            </Button>
            <Button
              onClick={nextAddress}
              sx={{ cursor: 'pointer', width: '50%', ml: "5px" }}
              variant="outlined"
              color="secondary"
            >
              Next Address
            </Button>
          </Box>
        </Box>
      </Box>
    </Box>

  );
}

export default App;