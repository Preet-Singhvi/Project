import { Box } from "@mui/material";

const IframeComponent = ({src}) => {
    return (
      <Box sx={{height:'100%', widt:'100%'}}>
        <iframe src={src} width="100%" height="100%"/>
      </Box>
    );
  };

export default IframeComponent