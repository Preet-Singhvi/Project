import * as React from 'react';
import './App.css';
import { useState, useEffect } from "react";
import { Box, Button, Grid, Stack, Switch, Typography } from "@mui/material";
import addresses from '../src/addresses.json';
import { createRoot } from 'react-dom/client';

import BingMapComponent from './BingMapComponent/BingMapComponent.js'
import IframeComponent from './iframeComponent/iframeComponent';
import StreetView from './StreetView/StreetView';

const App = () => {

  const [saddresses, setAddresses] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    setAddresses(addresses);
  }, []);

  const previousAddress = () => {
    setCurrentIndex(currentIndex > 0 ? currentIndex - 1 : saddresses.length - 1);
  };

  const nextAddress = () => {
    setCurrentIndex(currentIndex < saddresses.length - 1 ? currentIndex + 1 : 0);
  };

  const [currentAddressIndex, setCurrentAddressIndex] = useState(0);
  const [secondIframeSrc, setSecondIframeSrc] = useState(saddresses[currentIndex]?.google_url);
  const [isIframeShown, setIsIframeShown] = useState(true);
  const [showStreetView, setShowStreetView] = useState(false);

  const ToggleStreetView = () => {
    try {
      setShowStreetView(!showStreetView);
    } catch (error) {
      console.error(error);
    }
  }

  const toggleMap = () => {
    if (isIframeShown) {
      setIsIframeShown(false);
    } else {
      setIsIframeShown(true);
    }
  };

  useEffect(() => {
    setSecondIframeSrc(saddresses[currentIndex]?.google_url);
  }, [saddresses, currentIndex]);

  return (
    <Box className="App"
      sx={{
        display: 'grid',
        gap: 1,
        gridTemplateColumns: 'repeat(2, 1fr)',
      }}
    >
      <Grid item>
        <IframeComponent src={saddresses[currentIndex]?.bdc_url} />
      </Grid>

      <Grid item>
        {!showStreetView ? 
        (isIframeShown ? (
          <IframeComponent src={secondIframeSrc} />) : 
          (<BingMapComponent address={saddresses[currentIndex]?.address} />)) 
        : <StreetView address={saddresses[currentIndex]?.address} />
        }
      </Grid>

      <Grid item>
        <Typography style={{ fontSize: 18 }}>Address: {saddresses[currentIndex]?.address}</Typography>
        <Box style={{ width: "900px", height: "150px", marginLeft: "20px" }}>
          <textarea placeholder="Enter your comment here" style={{ width: "100%", height: "100%" }} />
        </Box>
      </Grid>

      {/* <Grid item sx={{border:'1px solid red'}}>
        <Box>
          <Typography style={{ fontSize: 36, marginLeft: -275 }}>Challenge:</Typography>
          <Box style={{ display: 'flex', alignItems: 'center', marginTop: 0 }}>
            <Button variant="contained" color="success" style={{ fontSize: 30, marginLeft: 250, marginRight: 10 }}>
              Yes
            </Button>
            <Button variant="contained" color="error" style={{ fontSize: 30, marginRight: 50 }}>
              No
            </Button>
            <Button
              variant="contained"
              style={{ fontSize: 20 }}
              onClick={toggleMap}
            >
              {isIframeShown ? "Switch to Bing" : "Switch to Google"}
            </Button>
          </Box>
          <Box style={{ display: 'flex', marginTop: 15 }}>
            <Button
              onClick={previousAddress}
              style={{ fontSize: 24, cursor: "pointer", marginLeft: 200, marginRight: 10 }}
              variant="outlined"
              color="primary"
            >
              Previous Address
            </Button>
            <Button
              onClick={nextAddress}
              style={{ fontSize: 24, cursor: "pointer" }}
              variant="outlined"
              color="secondary"
            >
              Next Address
            </Button>
          </Box>
        </Box>
      </Grid> */}
      <Grid item sx={{ border: '1px solid red', display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ height: '70%', display: 'flex', flexDirection: 'row', border: '1px solid green' }}>
          <Box sx={{ width: '50%', display: 'flex', flexDirection: 'column', border: '1px solid green', alignItems: 'center' }}>
            {/* <Box> */}
            <Typography>Challenge:</Typography>
            <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', margin: 'auto', height: '90%', width: '100%' }}>
              <Button variant="contained" color="success"
                sx={{ margin: '10px', width: '30%' }}
              // style={{ fontSize: 30, marginLeft: 250, marginRight: 10 }}
              >
                Yes
              </Button>
              <Button variant="contained" color="error"
                sx={{ margin: '10px', width: '30%' }}
              // style={{ fontSize: 30, marginRight: 50 }}
              >
                No
              </Button>
            </Box>
            {/* </Box> */}

          </Box>
          <Box sx={{ width: '50%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', border: '1px solid green' }}>
            <Stack
              direction="row"
              spacing={1}
              sx={{ alignItems: 'center', height: '40%', width: '100%', justifyContent: 'flex-start' }}
            >
              <Typography className='App-typography'>Switch to Bing</Typography>
              <Switch
                checked={isIframeShown}
                onChange={toggleMap}
              />
              <Typography>Switch to Google</Typography>
            </Stack>
            {/* <Box sx={{display: 'flex', flexDirection: 'row', alignItems:'center',justifyContent:'center'}}> */}
            {/* <Typography sx={{marginRight:'15px'}}>StreetView</Typography> */}
            <Stack
              direction="row"
              spacing={1}
              sx={{ alignItems: 'center', height: '40%', width: '100%', justifyContent: 'flex-start' }}
            >
              <Typography className='App-typography'>StreetView Off</Typography>
              <Switch
                checked={showStreetView}
                onChange={ToggleStreetView}
              />
              <Typography>On</Typography>
            </Stack>
            {/* </Box> */}

          </Box>
        </Box>
        <Box sx={{ height: '30%', width: '100%', display: 'flex', flexDirection: 'row', border: '1px solid blue', alignItems: 'center', justifyContent: 'space-between' }}>
          <Button
            onClick={previousAddress}
            sx={{ cursor: 'pointer' }}
            variant="outlined"
            color="primary"
          >
            Previous Address
          </Button>
          <Button
            onClick={nextAddress}
            sx={{ cursor: 'pointer' }}
            variant="outlined"
            color="secondary"
          >
            Next Address
          </Button>
        </Box>
      </Grid>
    </Box>
  );
}

export default App;